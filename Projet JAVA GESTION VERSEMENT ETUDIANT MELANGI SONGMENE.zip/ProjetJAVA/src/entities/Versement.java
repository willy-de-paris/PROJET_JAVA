/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import utils.Jdbc;

/**
 *
 * @author Rodrigue Ngok
 */
public class Versement {
    String mat;
    Date dateversement;
    int montant;

    public Versement() {
    }

    public Versement(String mat, Date dateversement, int montant) {
        this.mat = mat;
        this.dateversement = dateversement;
        this.montant = montant;
    }

    public void setMat(String mat) {
        this.mat = mat;
    }

    public void setDateversement(Date dateversement) {
        this.dateversement = dateversement;
    }

    public void setMontant(int montant) {
        this.montant = montant;
    }

    public String getMat() {
        return mat;
    }

    public Date getDateversement() {
        return dateversement;
    }

    public int getMontant() {
        return montant;
    }
    public void saveversement(String mat, java.sql.Date dateversement, int montant) throws SQLException {

        String command = "Insert into Versement( matricule, dateversement, montan) VALUES(?,?,?)";

        PreparedStatement addstmt = Jdbc.getConnexion().prepareStatement(command);

        addstmt.setObject(1, mat);
        addstmt.setObject(2, dateversement);
        addstmt.setObject(3, montant);
        addstmt.executeUpdate();

    }
    
    public void deleteversement(String mat ) throws SQLException {
        String command = "delete from Versement where matricule=?";
        PreparedStatement deletestmt = Jdbc.getConnexion().prepareStatement(command);
        deletestmt.setObject(1, mat);
        deletestmt.execute();

    }

    public void updateversement(String montant, String mat) throws SQLException {

        String command = "update Versement set montant=? where matricule=?";

        PreparedStatement modifystmt = Jdbc.getConnexion().prepareStatement(command);

        modifystmt.setObject(1, montant);
        modifystmt.execute();

    }
    
}
