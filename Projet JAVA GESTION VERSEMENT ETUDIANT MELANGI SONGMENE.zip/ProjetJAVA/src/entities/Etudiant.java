/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import utils.Jdbc;

/**
 *
 * @author Rodrigue Ngok
 */
public class Etudiant {

    String nom, genre, mat, email, telephone;
    Date datenais;

    public Etudiant() {
    }

    public Etudiant(String nom, String email, String genre, String mat, String telephone, Date datenais) {
        this.nom = nom;
        this.email = email;
        this.genre = genre;
        this.mat = mat;
        this.telephone = telephone;
        this.datenais = datenais;
    }

    //getters
    public String getName() {
        return this.nom;
    }

    public String getGenre() {
        return this.genre;
    }

    public String getEmail() {
        return this.email;
    }

    public String getMat() {
        return this.mat;
    }

    public String getTelephone() {
        return this.telephone;
    }

    /**
     *
     * @return
     */
    public Date getDatenais() {
        return this.datenais;
    }

    public void save(String mat, String nom, String genre, Date datenais, String telephone, String email) throws SQLException {

        String command = "Insert into Etudiant( matricule, nom, genre, datenaissance, telephone, email) VALUES(?,?,?,?,?,?)";

        PreparedStatement addstmt = Jdbc.getConnexion().prepareStatement(command);

        addstmt.setObject(1, mat);
        addstmt.setObject(2, nom);
        addstmt.setObject(3, genre);
        addstmt.setObject(4, datenais);
        addstmt.setObject(5, telephone);
        addstmt.setObject(6, email);
        addstmt.executeUpdate();

    }

    public List<Etudiant> getAllEtudiant() throws SQLException {
        String cmd = "select * from etudiant";
        PreparedStatement stmt = Jdbc.getConnexion().prepareStatement(cmd);

        ResultSet en = stmt.executeQuery();
        List<Etudiant> list = new ArrayList<>();

        while (en.next()) {
            list.add(new Etudiant(en.getString(1), en.getString(2), en.getString(3), en.getString(4), en.getString(5), en.getDate(6)));
        }

        return list;

    }

    public void deletetudiant(String matricule) throws SQLException {
        String command = "delete from etudiant where matricule=?";
        PreparedStatement deletestmt = Jdbc.getConnexion().prepareStatement(command);
        deletestmt.setObject(1, matricule);
        deletestmt.execute();

    }

    public void updatetelephone(String matricule, String telephone) throws SQLException {

        String command = "update etudiant set telephone=? where matricule=?";

        PreparedStatement modifystmt = Jdbc.getConnexion().prepareStatement(command);

        modifystmt.setObject(1, telephone);
        modifystmt.setObject(2, matricule);
        modifystmt.execute();

    }
}
